/**
 * A Maybe<T> monad, representing a value or the absence thereof.
 */
export declare class Maybe<T> {
    private valueField;
    private isSomeField;
    /**
     * Instantiates a new instance of the {@link Maybe<T>} class.
     * @param value The value represented by this {@link Maybe<T>}, or
     * {@link null} or {@link undefined} to represent the absence of
     * a value.
     */
    constructor(value?: T);
    /**
     * The value represented by this {@link Maybe<T>}.
     * Throws an error if the value is absent.
     */
    readonly value: T;
    /**
     * A value indicating this {@link Maybe<T>} represents a value.
     */
    readonly isSome: boolean;
    /**
     * A value indicating this {@link Maybe<T>} does not represent
     * a value.
     */
    readonly isNone: boolean;
    /**
     * A {@link Maybe<T>} representing the absence of a value.
     */
    static none<T>(): Maybe<T>;
    /**
     * A {@link Maybe<T>} representing the specified value.
     * @param value The value of the resulting {@link Maybe<T>}.
     */
    static some<T>(value: T): Maybe<T>;
    /**
     * Maps this {@link Maybe<T>} into a new form when possible.
     * @param selector The function projecting this T into a new form.
     * @returns Returns a new {@link Maybe<T>} with the result of the
     * selector.
     */
    map<U>(selector: (value: T) => U): Maybe<U>;
    /**
     * Binds a computations that could result in none to another
     * computation that does this.
     * @param transform The computation on this {@link Maybe<T>}
     * that results in a {@link Maybe<T>}.
     * @returns Returns the result of transform.
     */
    bind<U>(transform: (value: T) => Maybe<U>): Maybe<U>;
    /**
     * The value of this {@link Maybe<T>} or a different value if
     * it is none.
     * @param value The alternative value to return when this
     * {@link Maybe<T>} is none.
     * @returns Returns the value of this {@link Maybe<T>} or an
     * alternative value when it is none.
     */
    valueOrElse(value: T): T;
    /**
     * Maps this {@link Maybe<T>} into a new form or return
     * a different value if it is none.
     * @param some The function projecting this T into a new form.
     * @param none The alternative value to return when this
     * {@link Maybe<T>} is none.
     * @returns Returns the value of some or the none value if this
     * {@link Maybe<T>} is none.
     */
    match<U>(some: (value: T) => U, none: U): U;
    /**
     * Compare this {@link Maybe<T>} to another {@link Maybe<T>}.
     * @param compareTo The {@link Maybe<T>} to compare this
     * {@link Maybe<T>} to.
     * @returns Returns true when they are equal; otherwise false.
     */
    equals(compareTo: Maybe<T>): boolean;
    /**
     * Serializes this maybe into a IMaybe which can be send to the back-end.
     * @returns Returns the new IMaybe instance.
     */
    serialize(): IMaybe<T>;
    /**
     * Converts this maybe to a query string parameter. Note that this only works for primitive types.
     * For complex types use a body parameter with .serialize().
     * @returns The query string value for this maybe object.
     */
    asQueryParam(): string;
    /**
     * Converts this maybe to a query string parameter. This method is only meant to be used on maybes for enum types,
     * since it can not be easily determined if the type is an enum by itself. This method does not do any checking and
     * should therefore be used with caution.
     * For other types use asQueryParam() or serialize().
     * @returns The query string value for this maybe object.
     */
    asEnumQueryParam(): string;
    /**
     * Deserializes the given IMaybe into a Maybe.
     * @param dto The IMaybe to deserialize.
     * @returns Returns the new Maybe instance.
     */
    static deserialize<T>(dto: IMaybe<T>): Maybe<T>;
}
export interface IMaybe<T> {
    isSome: boolean;
    value: T;
}
/**
 * A class providing extensions on the native array implementation.
 * @param <T> The type of the elements of the source array.
 */
export declare class Wv8Array<T> {
    /**
     * Gets or sets the underlying array.
     */
    private value;
    /**
     * Gets the length of the array. This is a number one higher than the highest element defined in an array.
     */
    readonly length: number;
    constructor(value?: Array<T>);
    /**
     * Gets the item with the given index.
     */
    get(index: number): T;
    /**
     * Groups the element of a sequence according to a specified key selector function.
     * @param <TKey> The type of the key returned by {@link keySelector}.
     * @param keySelector A function to extract the key for each element.
     * @param comparer A function used to determine whether two key values are equal. Can be null when default
     * comparison should be used.
     * @return An {@link IKeyValuePair<TKey, TSource[]>[]} where each {@link IKeyValuePair<TKey, TSource[]>}
     * contains
     * a sequence of objects and a key.
     */
    groupBy<TKey>(keySelector: (value: T) => TKey, comparer?: (a: TKey, b: TKey) => boolean): Wv8Array<IKeyValuePair<TKey, Wv8Array<T>>>;
    /**
     * Returns the first element of a sequence that matches the condition, or a default value if the sequence
     * contains no elements that match the condition.
     * @param <T> The type of the elements of the array.
     * @param condition A function to test an element for a condition.
     * @param defaultValue The default value which is returned if the sequence contains no elements that match the
     * condition. By default null is used.
     * @return The first element of the input sequence that satisfies a condition, otherwise {@link defaultValue}.
     */
    firstOrDefault(condition: (value: T) => boolean, defaultValue?: T): T;
    /**
     * Returns a new array with all the distinct values of the source array based on the result of the compare
     * function.
     * @param comparer A function that will be called for each element to compare and should return if the elements
     * are the same or not.
     * @return A new array containing the distinct values of the source array.
     */
    distinct(comparer: (value1: T, value2: T) => boolean): Wv8Array<T>;
    /**
     * Removes the first occurrence of an item from the array if it exists
     * @param item The item to remove from the array.
     * @return True when the remove succeeded, otherwise false.
     */
    remove(item: T): boolean;
    /**
     * Removes all items from the array.
     */
    removeAll(): any;
    /**
     * Removes all items from the array that satisfy a condition.
     * @param condition A function to test an element for a condition.
     */
    removeAll(condition: (value: T) => boolean): any;
    /**
     * Projects each item of the array to an array and flattens the resulting arrays into one array.
     * @param <TResult> The type of the array that is returned.
     * @param selector A function to apply to each item.
     * @return An array whose items are the result of invoking the one-to-many selector function on each item of
     * this array.
     */
    selectMany<TResult>(selector: (value: T) => TResult[]): Wv8Array<TResult>;
    /**
     * Copies the elements of {@link Wv8Array<T>} to a new array.
     * @return An array containing copies of the elements in {@link Wv8Array<T>}.
     */
    toArray(): Array<T>;
    /**
     * Casts the {@link Wv8Array<T>} to a {@link Array<T>}.
     * @return The {@link Wv8Array<T>} as {@link Array<T>}.
     */
    asArray(): Array<T>;
    /**
     * Returns a string representation of an array.
     */
    toString(): string;
    /**
     * Returns a localized string representation of an array.
     */
    toLocaleString(): string;
    /**
     * Combines two or more arrays.
     * @param items Additional items to add to the end of array1.
     */
    concat<U extends Wv8Array<T>>(...items: U[]): Wv8Array<T>;
    /**
     * Combines two or more arrays.
     * @param items Additional items to add to the end of array1.
     */
    concat(...items: T[]): Wv8Array<T>;
    /**
     * Adds all the elements of an array separated by the specified separator string.
     * @param separator A string used to separate one element of an array from the next in the resulting String.
     * If omitted, the array elements are separated with a comma.
     */
    join(separator?: string): string;
    /**
     * Removes the last element from an array and returns it.
     */
    pop(): T;
    /**
     * Appends new elements to an array, and returns the new length of the array.
     * @param items New elements of the Array.
     */
    push(...items: T[]): number;
    /**
     * Reverses the elements in an Array.
     */
    reverse(): Wv8Array<T>;
    /**
     * Removes the first element from an array and returns it.
     */
    shift(): T;
    /**
     * Returns a section of an array.
     * @param start The beginning of the specified portion of the array.
     * @param end The end of the specified portion of the array.
     */
    slice(start: number, end?: number): Wv8Array<T>;
    /**
     * Sorts an array.
     * @param compareFn The name of the function used to determine the order of the elements. If omitted, the
     * elements are sorted in ascending, ASCII character order.
     */
    sort(compareFn?: (a: T, b: T) => number): Wv8Array<T>;
    /**
     * Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted
     * elements.
     * @param start The zero-based location in the array from which to start removing elements.
     */
    splice(start: number): Wv8Array<T>;
    /**
     * Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted
     * elements.
     * @param start The zero-based location in the array from which to start removing elements.
     * @param deleteCount The number of elements to remove.
     * @param items Elements to insert into the array in place of the deleted elements.
     */
    splice(start: number, deleteCount: number, ...items: T[]): Wv8Array<T>;
    /**
     * Inserts new elements at the start of an array.
     * @param items  Elements to insert at the start of the Array.
     */
    unshift(...items: T[]): number;
    /**
     * Returns the index of the first occurrence of a value in an array.
     * @param searchElement The value to locate in the array.
     * @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at
     *  index 0.
     */
    indexOf(searchElement: T, fromIndex?: number): number;
    /**
     * Returns the index of the last occurrence of a specified value in an array.
     * @param searchElement The value to locate in the array.
     * @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at
     *  the last index in the array.
     */
    lastIndexOf(searchElement: T, fromIndex?: number): number;
    /**
     * Determines whether all the members of an array satisfy the specified test.
     * @param callbackfn A function that accepts up to three arguments. The every method calls the callbackfn
     * function for each element in array1 until the callbackfn returns false, or until the end of the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    every(callbackfn: (value: T, index: number, array: Wv8Array<T>) => boolean, thisArg?: any): boolean;
    /**
     * Determines whether the specified callback function returns true for any element of an array.
     * @param callbackfn A function that accepts up to three arguments. The some method calls the callbackfn
     * function for each element in array1 until the callbackfn returns true, or until the end of the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    some(callbackfn: (value: T, index: number, array: Wv8Array<T>) => boolean, thisArg?: any): boolean;
    /**
     * Performs the specified action for each element in an array.
     * @param callbackfn  A function that accepts up to three arguments. forEach calls the callbackfn function
     * one time for each element in the array.
     * @param thisArg  An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    forEach(callbackfn: (value: T, index: number, array: Wv8Array<T>) => void, thisArg?: any): void;
    /**
     * Calls a defined callback function on each element of an array, and returns an array that contains the
     * results.
     * @param callbackfn A function that accepts up to three arguments. The map method calls the callbackfn
     * function one time for each element in the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    map<U>(callbackfn: (value: T, index: number, array: Wv8Array<T>) => U, thisArg?: any): Wv8Array<U>;
    /**
     * Returns the elements of an array that meet the condition specified in a callback function.
     * @param callbackfn A function that accepts up to three arguments. The filter method calls the callbackfn
     * function one time for each element in the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    filter(callbackfn: (value: T, index: number, array: Wv8Array<T>) => boolean, thisArg?: any): Wv8Array<T>;
    /**
     * Calls the specified callback function for all the elements in an array. The return value of the callback
     * function is the accumulated result, and is provided as an argument in the next call to the callback function.
     * @param callbackfn A function that accepts up to four arguments. The reduce method calls the callbackfn
     * function one time for each element in the array.
     * @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation.
     * The first call to the callbackfn function provides this value as an argument instead of an array value.
     */
    reduce(callbackfn: (previousValue: T, currentValue: T, currentIndex: number, array: Wv8Array<T>) => T, initialValue?: T): T;
    /**
     * Calls the specified callback function for all the elements in an array. The return value of the callback
     * function is the accumulated result, and is provided as an argument in the next call to the callback function.
     * @param callbackfn A function that accepts up to four arguments. The reduce method calls the callbackfn
     * function one time for each element in the array.
     * @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation.
     * The first call to the callbackfn function provides this value as an argument instead of an array value.
     */
    reduce<U>(callbackfn: (previousValue: U, currentValue: T, currentIndex: number, array: Wv8Array<T>) => U, initialValue: U): U;
    /**
     * Calls the specified callback function for all the elements in an array, in descending order. The return
     * value of the callback function is the accumulated result, and is provided as an argument in the next call
     * to the callback function.
     * @param callbackfn A function that accepts up to four arguments. The reduceRight method calls the callbackfn
     * function one time for each element in the array.
     * @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation.
     * The first call to the callbackfn function provides this value as an argument instead of an array value.
     */
    reduceRight(callbackfn: (previousValue: T, currentValue: T, currentIndex: number, array: Wv8Array<T>) => T, initialValue?: T): T;
    /**
     * Calls the specified callback function for all the elements in an array, in descending order. The return
     * value of the callback function is the accumulated result, and is provided as an argument in the next call
     * to the callback function.
     * @param callbackfn A function that accepts up to four arguments. The reduceRight method calls the callbackfn
     * function one time for each element in the array.
     * @param initialValue If initialValue is specified, it is used as the initial value to start the accumulation.
     * The first call to the callbackfn function provides this value as an argument instead of an array value.
     */
    reduceRight<U>(callbackfn: (previousValue: U, currentValue: T, currentIndex: number, array: Wv8Array<T>) => U, initialValue: U): U;
}
/**
 * Defines a key/value pair that can be set or retrieved.
 * @param <TKey> The type of the key.
 * @param <TValue> The type of the value.
 */
export interface IKeyValuePair<TKey, TValue> {
    /**
     * The key of the key/value pair.
     */
    Key: TKey;
    /**
     * The value of the key/value pair.
     */
    Value: TValue;
}
