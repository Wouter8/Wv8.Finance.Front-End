"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * A Maybe<T> monad, representing a value or the absence thereof.
 */
var Maybe = /** @class */ (function () {
    /**
     * Instantiates a new instance of the {@link Maybe<T>} class.
     * @param value The value represented by this {@link Maybe<T>}, or
     * {@link null} or {@link undefined} to represent the absence of
     * a value.
     */
    function Maybe(value) {
        if (value === void 0) { value = null; }
        if (value !== null && value !== undefined) {
            this.valueField = value;
            this.isSomeField = true;
        }
        else {
            this.valueField = null;
            this.isSomeField = false;
        }
    }
    Object.defineProperty(Maybe.prototype, "value", {
        /**
         * The value represented by this {@link Maybe<T>}.
         * Throws an error if the value is absent.
         */
        get: function () {
            if (this.isSomeField) {
                return this.valueField;
            }
            throw new Error("Cannot retrieve the value of none.");
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Maybe.prototype, "isSome", {
        /**
         * A value indicating this {@link Maybe<T>} represents a value.
         */
        get: function () {
            return this.isSomeField;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Maybe.prototype, "isNone", {
        /**
         * A value indicating this {@link Maybe<T>} does not represent
         * a value.
         */
        get: function () {
            return !this.isSomeField;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * A {@link Maybe<T>} representing the absence of a value.
     */
    Maybe.none = function () {
        return new Maybe();
    };
    /**
     * A {@link Maybe<T>} representing the specified value.
     * @param value The value of the resulting {@link Maybe<T>}.
     */
    Maybe.some = function (value) {
        return new Maybe(value);
    };
    /**
     * Maps this {@link Maybe<T>} into a new form when possible.
     * @param selector The function projecting this T into a new form.
     * @returns Returns a new {@link Maybe<T>} with the result of the
     * selector.
     */
    Maybe.prototype.map = function (selector) {
        return this.isSome
            ? new Maybe(selector(this.value))
            : Maybe.none();
    };
    /**
     * Binds a computations that could result in none to another
     * computation that does this.
     * @param transform The computation on this {@link Maybe<T>}
     * that results in a {@link Maybe<T>}.
     * @returns Returns the result of transform.
     */
    Maybe.prototype.bind = function (transform) {
        return this.isSome
            ? transform(this.value)
            : Maybe.none();
    };
    /**
     * The value of this {@link Maybe<T>} or a different value if
     * it is none.
     * @param value The alternative value to return when this
     * {@link Maybe<T>} is none.
     * @returns Returns the value of this {@link Maybe<T>} or an
     * alternative value when it is none.
     */
    Maybe.prototype.valueOrElse = function (value) {
        return this.isSome
            ? this.value
            : value;
    };
    /**
     * Maps this {@link Maybe<T>} into a new form or return
     * a different value if it is none.
     * @param some The function projecting this T into a new form.
     * @param none The alternative value to return when this
     * {@link Maybe<T>} is none.
     * @returns Returns the value of some or the none value if this
     * {@link Maybe<T>} is none.
     */
    Maybe.prototype.match = function (some, none) {
        return this.isSome
            ? some(this.value)
            : none;
    };
    /**
     * Compare this {@link Maybe<T>} to another {@link Maybe<T>}.
     * @param compareTo The {@link Maybe<T>} to compare this
     * {@link Maybe<T>} to.
     * @returns Returns true when they are equal; otherwise false.
     */
    Maybe.prototype.equals = function (compareTo) {
        return this.isSome && compareTo.isSome
            ? this.value === compareTo.value
            : this.isNone && compareTo.isNone;
    };
    /**
     * Serializes this maybe into a IMaybe which can be send to the back-end.
     * @returns Returns the new IMaybe instance.
     */
    Maybe.prototype.serialize = function () {
        return { isSome: this.isSomeField, value: this.valueField };
    };
    /**
     * Converts this maybe to a query string parameter. Note that this only works for primitive types.
     * For complex types use a body parameter with .serialize().
     * @returns The query string value for this maybe object.
     */
    Maybe.prototype.asQueryParam = function () {
        if (!this.isSome)
            return '';
        if (typeof (this.value) === "string")
            return this.value;
        if (Array.isArray(this.value))
            throw new Error("Can't use Maybe as query string parameter when it contains a list.");
        if (typeof (this.value) === "object")
            throw new Error("Complex objects are not supported as query parameter, please use a body parameter with serialize().");
        return JSON.stringify(this.value);
    };
    /**
     * Deserializes the given IMaybe into a Maybe.
     * @param dto The IMaybe to deserialize.
     * @returns Returns the new Maybe instance.
     */
    Maybe.deserialize = function (dto) {
        if (typeof (dto.isSome) !== "boolean"
            || ((dto.value === null || dto.value === undefined) && dto.isSome)
            || (dto.value !== null && dto.value !== undefined && !dto.isSome)) {
            throw new Error("Invalid IMaybe object. Property 'isSome' needs to be a boolean and if it is true property "
                + "'value' cannot be null or undefined and visa versa.");
        }
        return new Maybe(dto.value);
    };
    return Maybe;
}());
exports.Maybe = Maybe;
/**
 * A class providing extensions on the native array implementation.
 * @param <T> The type of the elements of the source array.
 */
var Wv8Array = /** @class */ (function () {
    // #endregion Field
    // #region Constructor
    function Wv8Array(value) {
        if (value === void 0) { value = []; }
        // #region Field
        /**
         * Gets or sets the underlying array.
         */
        this.value = [];
        this.value = value;
    }
    Object.defineProperty(Wv8Array.prototype, "length", {
        /**
         * Gets the length of the array. This is a number one higher than the highest element defined in an array.
         */
        get: function () {
            return this.value.length;
        },
        enumerable: true,
        configurable: true
    });
    // #endregion Constructor
    // #region Wv8Array
    /**
     * Gets the item with the given index.
     */
    Wv8Array.prototype.get = function (index) {
        return this.value[index];
    };
    /**
    * Groups the element of a sequence according to a specified key selector function.
    * @param <TKey> The type of the key returned by {@link keySelector}.
    * @param keySelector A function to extract the key for each element.
    * @param comparer A function used to determine whether two key values are equal. Can be null when default
    * comparison should be used.
    * @return An {@link IKeyValuePair<TKey, TSource[]>[]} where each {@link IKeyValuePair<TKey, TSource[]>}
    * contains
    * a sequence of objects and a key.
    */
    Wv8Array.prototype.groupBy = function (keySelector, comparer) {
        if (comparer === void 0) { comparer = null; }
        var groupedValues = new Wv8Array();
        this.forEach(function (item) {
            var groupedValue = groupedValues.firstOrDefault(function (value) {
                return (comparer ? comparer(value.Key, keySelector(item)) : value.Key === keySelector(item));
            });
            if (groupedValue === null || groupedValue === undefined) {
                groupedValue = { Key: keySelector(item), Value: new Wv8Array() };
                groupedValues.push(groupedValue); // Any used to avoid ReSharper error.
            }
            groupedValue.Value.push(item);
        });
        return groupedValues;
    };
    /**
    * Returns the first element of a sequence that matches the condition, or a default value if the sequence
    * contains no elements that match the condition.
    * @param <T> The type of the elements of the array.
    * @param condition A function to test an element for a condition.
    * @param defaultValue The default value which is returned if the sequence contains no elements that match the
    * condition. By default null is used.
    * @return The first element of the input sequence that satisfies a condition, otherwise {@link defaultValue}.
    */
    Wv8Array.prototype.firstOrDefault = function (condition, defaultValue) {
        if (defaultValue === void 0) { defaultValue = null; }
        for (var i = 0; i < this.length; i++) {
            if (condition(this.value[i])) {
                return this.value[i];
            }
        }
        ;
        return defaultValue;
    };
    /**
     * Returns a new array with all the distinct values of the source array based on the result of the compare
     * function.
     * @param comparer A function that will be called for each element to compare and should return if the elements
     * are the same or not.
     * @return A new array containing the distinct values of the source array.
     */
    Wv8Array.prototype.distinct = function (comparer) {
        var distinctValues = new Wv8Array();
        this.forEach(function (value1) {
            // Check if the value is already in the distinctValues array, if not add it to the distinctValues array.
            if (!distinctValues.some(function (value2) { return comparer(value1, value2); })) {
                distinctValues.push(value1);
            }
        });
        return distinctValues;
    };
    /**
     * Removes the first occurrence of an item from the array if it exists
     * @param item The item to remove from the array.
     * @return True when the remove succeeded, otherwise false.
     */
    Wv8Array.prototype.remove = function (item) {
        // Check the index of the item in the array or -1 if it doesn't exist.
        var index = this.indexOf(item);
        if (index >= 0) {
            // Remove one item from the array at the index of the item
            return this.value.splice(index, 1).length === 1;
        }
        return false;
    };
    Wv8Array.prototype.removeAll = function (condition) {
        if (condition === null || condition === undefined) {
            while (this.length > 0) {
                this.value.pop();
            }
        }
        else {
            for (var i = this.length - 1; i >= 0; i--) {
                if (condition(this.value[i])) {
                    this.value.splice(i, 1);
                }
            }
        }
    };
    /**
     * Projects each item of the array to an array and flattens the resulting arrays into one array.
     * @param <TResult> The type of the array that is returned.
     * @param selector A function to apply to each item.
     * @return An array whose items are the result of invoking the one-to-many selector function on each item of
     * this array.
     */
    Wv8Array.prototype.selectMany = function (selector) {
        var result = new Wv8Array();
        this.forEach(function (x) { return selector(x).forEach(function (y) { return result.push(y); }); });
        return result;
    };
    /**
     * Copies the elements of {@link Wv8Array<T>} to a new array.
     * @return An array containing copies of the elements in {@link Wv8Array<T>}.
     */
    Wv8Array.prototype.toArray = function () {
        return this.value.slice(0);
    };
    /**
     * Casts the {@link Wv8Array<T>} to a {@link Array<T>}.
     * @return The {@link Wv8Array<T>} as {@link Array<T>}.
     */
    Wv8Array.prototype.asArray = function () {
        return this.value;
    };
    // #endregion Wv8Array
    // #region Native
    /**
     * Returns a string representation of an array.
     */
    Wv8Array.prototype.toString = function () {
        return this.value.toString.apply(this.value, arguments);
    };
    /**
     * Returns a localized string representation of an array.
     */
    Wv8Array.prototype.toLocaleString = function () {
        return this.value.toLocaleString.apply(this.value, arguments);
    };
    Wv8Array.prototype.concat = function () {
        return new Wv8Array(this.value.concat.apply(this.value, arguments));
    };
    /**
     * Adds all the elements of an array separated by the specified separator string.
     * @param separator A string used to separate one element of an array from the next in the resulting String.
     * If omitted, the array elements are separated with a comma.
     */
    Wv8Array.prototype.join = function (separator) {
        return this.value.join.apply(this.value, arguments);
    };
    /**
     * Removes the last element from an array and returns it.
     */
    Wv8Array.prototype.pop = function () {
        return this.value.pop.apply(this.value, arguments);
    };
    /**
     * Appends new elements to an array, and returns the new length of the array.
     * @param items New elements of the Array.
     */
    Wv8Array.prototype.push = function () {
        var items = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            items[_i] = arguments[_i];
        }
        return this.value.push.apply(this.value, arguments);
    };
    /**
     * Reverses the elements in an Array.
     */
    Wv8Array.prototype.reverse = function () {
        return new Wv8Array(this.value.reverse.apply(this.value, arguments));
    };
    /**
     * Removes the first element from an array and returns it.
     */
    Wv8Array.prototype.shift = function () {
        return this.value.shift.apply(this.value, arguments);
    };
    /**
     * Returns a section of an array.
     * @param start The beginning of the specified portion of the array.
     * @param end The end of the specified portion of the array.
     */
    Wv8Array.prototype.slice = function (start, end) {
        return new Wv8Array(this.value.slice.apply(this.value, arguments));
    };
    /**
     * Sorts an array.
     * @param compareFn The name of the function used to determine the order of the elements. If omitted, the
     * elements are sorted in ascending, ASCII character order.
     */
    Wv8Array.prototype.sort = function (compareFn) {
        return new Wv8Array(this.value.sort.apply(this.value, arguments));
    };
    Wv8Array.prototype.splice = function () {
        return new Wv8Array(this.value.splice.apply(this.value, arguments));
    };
    /**
     * Inserts new elements at the start of an array.
     * @param items  Elements to insert at the start of the Array.
     */
    Wv8Array.prototype.unshift = function () {
        var items = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            items[_i] = arguments[_i];
        }
        return this.value.unshift.apply(this.value, arguments);
    };
    /**
     * Returns the index of the first occurrence of a value in an array.
     * @param searchElement The value to locate in the array.
     * @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at
     *  index 0.
     */
    Wv8Array.prototype.indexOf = function (searchElement, fromIndex) {
        return this.value.indexOf.apply(this.value, arguments);
    };
    /**
     * Returns the index of the last occurrence of a specified value in an array.
     * @param searchElement The value to locate in the array.
     * @param fromIndex The array index at which to begin the search. If fromIndex is omitted, the search starts at
     *  the last index in the array.
     */
    Wv8Array.prototype.lastIndexOf = function (searchElement, fromIndex) {
        return this.value.lastIndexOf.apply(this.value, arguments);
    };
    /**
     * Determines whether all the members of an array satisfy the specified test.
     * @param callbackfn A function that accepts up to three arguments. The every method calls the callbackfn
     * function for each element in array1 until the callbackfn returns false, or until the end of the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    Wv8Array.prototype.every = function (callbackfn, thisArg) {
        var wrapper = function (value, index, array) {
            return callbackfn(value, index, new Wv8Array(array));
        };
        return this.value.every(wrapper, thisArg);
    };
    /**
     * Determines whether the specified callback function returns true for any element of an array.
     * @param callbackfn A function that accepts up to three arguments. The some method calls the callbackfn
     * function for each element in array1 until the callbackfn returns true, or until the end of the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    Wv8Array.prototype.some = function (callbackfn, thisArg) {
        var wrapper = function (value, index, array) {
            return callbackfn(value, index, new Wv8Array(array));
        };
        return this.value.some(wrapper, thisArg);
    };
    /**
     * Performs the specified action for each element in an array.
     * @param callbackfn  A function that accepts up to three arguments. forEach calls the callbackfn function
     * one time for each element in the array.
     * @param thisArg  An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    Wv8Array.prototype.forEach = function (callbackfn, thisArg) {
        var wrapper = function (value, index, array) {
            callbackfn(value, index, new Wv8Array(array));
        };
        this.value.forEach(wrapper, thisArg);
    };
    /**
     * Calls a defined callback function on each element of an array, and returns an array that contains the
     * results.
     * @param callbackfn A function that accepts up to three arguments. The map method calls the callbackfn
     * function one time for each element in the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    Wv8Array.prototype.map = function (callbackfn, thisArg) {
        var wrapper = function (value, index, array) {
            return callbackfn(value, index, new Wv8Array(array));
        };
        return new Wv8Array(this.value.map(wrapper, thisArg));
    };
    /**
     * Returns the elements of an array that meet the condition specified in a callback function.
     * @param callbackfn A function that accepts up to three arguments. The filter method calls the callbackfn
     * function one time for each element in the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is
     * omitted, undefined is used as the this value.
     */
    Wv8Array.prototype.filter = function (callbackfn, thisArg) {
        var wrapper = function (value, index, array) {
            return callbackfn(value, index, new Wv8Array(array));
        };
        return new Wv8Array(this.value.filter(wrapper, thisArg));
    };
    Wv8Array.prototype.reduce = function (callbackfn, initialValue) {
        var wrapper = function (previousValue, currentValue, currentIndex, array) {
            return callbackfn(previousValue, currentValue, currentIndex, new Wv8Array(array));
        };
        return this.value.reduce(wrapper, initialValue);
    };
    Wv8Array.prototype.reduceRight = function (callbackfn, initialValue) {
        var wrapper = function (previousValue, currentValue, currentIndex, array) {
            return callbackfn(previousValue, currentValue, currentIndex, new Wv8Array(array));
        };
        return this.value.reduceRight(wrapper, initialValue);
    };
    return Wv8Array;
}());
exports.Wv8Array = Wv8Array;
